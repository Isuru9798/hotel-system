@extends('layouts.app')

@section('content')
@dd($checkin)
@endsection