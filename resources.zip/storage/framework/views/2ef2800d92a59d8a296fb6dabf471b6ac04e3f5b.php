

<?php $__env->startSection('css'); ?>

<style type="text/css">
    .save-btn {
        float: right;
    }

    .div-gap {
        margin-bottom: 2em;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('laundry-bill.add')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Room Id</label>
                    <select class="form-control" id="roomSelect" onclick="getRoomData()">
                        <option value="null">select room</option>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['checked_rooms_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Guest Name</label>
                    <input type="text" class="form-control" placeholder="Jone Doe" name="guest" id="guest" readonly>
                </div>
            </div>
            <div class="form-row ">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Date</label>
                    <input type="date" class="form-control" name="lon_issue_date" placeholder="dd/mm/yyyy" value="<?php echo e(old('lon_issue_date')); ?>">
                    <?php $__errorArgs = ['lon_issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Londry Item</label>
                    <input type="text" class="form-control" id="lon_item" name="lon_item" placeholder="Item Name" value="<?php echo e(old('lon_item')); ?>">
                    <?php $__errorArgs = ['lon_item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputCity">Quentity</label>
                    <input type="text" class="form-control" id="lon_quantity" name="lon_quantity" placeholder="0" value="<?php echo e(old('lon_quantity')); ?>">
                    <?php $__errorArgs = ['lon_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group col-md-2">
                    <label for="inputZip">Amount</label>
                    <input type="text" class="form-control" id="lon_amount" name="lon_amount" placeholder="Amount" value="<?php echo e(old('lon_amount')); ?>">
                    <?php $__errorArgs = ['lon_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <input type="hidden" id="checked_rooms_id" name="checked_rooms_id" value="">

            <button type="submit" class="btn btn-primary save-btn">Save changes</button>
        </form>
    </div>
</div>
<div class="div-gap"></div>
<div class="card">
    <div class="card-body">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Room Number</th>
                    <th>Londry Amount</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $laundry_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laundry_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($laundry_bill->rm_number); ?></td>
                    <td><?php echo e($laundry_bill->lon_amount); ?></td>
                    <td><?php echo e($laundry_bill->lon_quantity); ?></td>
                    <td><?php echo e($laundry_bill->lon_amount * $laundry_bill->lon_quantity); ?></td>
                    <td><?php echo e($laundry_bill->lon_issue_date); ?></td>

                    <?php if( $laundry_bill->lon_status == env('PAID')): ?>
                    <td>Paid</td>
                    <?php endif; ?>
                    <?php if( $laundry_bill->lon_status == env('UNPAID')): ?>
                    <td>Un Paid</td>
                    <?php endif; ?>
                    <?php if( $laundry_bill->lon_status == env('CANCELED')): ?>
                    <td>Canceled</td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('laundry-bill.cancel',$laundry_bill->laundry_id)); ?>">Cancel</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function getRoomData() {
        let roomId = $('#roomSelect').val();
        let _token = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('room-bills.getByRoom')); ?>",
            data: {
                id: roomId,
                _token: _token
            },
            success: function(data) {
                $('#checked_rooms_id').val(data.checked_rooms_id);
                $('#guest').val(data.gs_name);
                console.log(data);
            }
        });
    }

    function calCost() {
        $d_rate = $('#rb_doller_rate').val();
        $d_amount = $('#rb_amount_doller').val();
        $lkr_cost = $d_rate * $d_amount;
        $('#rb_cost').val($lkr_cost);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Infact_Project\hotel-system\resources\views/bill/laundry_bill.blade.php ENDPATH**/ ?>