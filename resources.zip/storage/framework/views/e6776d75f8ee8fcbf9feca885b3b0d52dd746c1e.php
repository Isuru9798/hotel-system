

<?php $__env->startSection('content'); ?>
<?php dd($checkin); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Infact_Project\hotel-system\resources\views/check-in/view-check-in.blade.php ENDPATH**/ ?>