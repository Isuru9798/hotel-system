

<?php $__env->startSection('css'); ?>

<style type="text/css">
    .save-btn {
        float: right;
    }

    .div-gap {
        margin-bottom: 2em;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('taxi-bill.add')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Room Id</label>
                    <select class="form-control" id="roomSelect" name="roomSelect" onclick="getRoomData()">
                        <option value="null">select room</option>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['checked_rooms_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Guest Name</label>
                    <input type="text" class="form-control" placeholder="Jone Doe" name="guest" id="guest" readonly>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Date</label>
                    <input type="date" class="form-control" name="tx_issue_date" placeholder="dd/mm/yyyy" value="<?php echo e(old('tx_issue_date')); ?>">
                    <?php $__errorArgs = ['tx_issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Destination</label>
                    <input type="text" class="form-control" id="tx_destination" name="tx_destination" placeholder="Destination" value="<?php echo e(old('tx_destination')); ?>">
                    <?php $__errorArgs = ['tx_destination'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="inputCity">Vehicle Number</label>
                    <input type="text" class="form-control" id="tx_vehicle_num" name="tx_vehicle_num" placeholder="BDB - 2244" value="<?php echo e(old('tx_vehicle_num')); ?>">
                    <?php $__errorArgs = ['tx_vehicle_num'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4">
                    <label for="inputZip">Amount</label>
                    <input type="text" class="form-control" id="tx_amount" name="tx_amount" placeholder="Amount" value="<?php echo e(old('tx_amount') ? old('tx_amount') : '0'); ?>" onkeyup="calCost()" value="<?php echo e(old('tx_amount')); ?>">
                    <?php $__errorArgs = ['tx_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4">
                    <label for="inputState">Number of Dayes</label>
                    <input type="text" class="form-control" id="tx_num_of_days" name="tx_num_of_days" placeholder="1" value="<?php echo e(old('tx_num_of_days') ? old('tx_num_of_days') : '0'); ?>" onkeyup="calCost()">
                    <?php $__errorArgs = ['tx_num_of_days'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Tax (%)</label>
                    <input type="text" class="form-control" id="tx_tax" name="tx_tax" value="0" value="<?php echo e(old('tx_tax') ? old('tx_tax') : '0'); ?>" placeholder="Taxt Amount" onkeyup="calCost()">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputZip">Total</label>
                    <input type="text" class="form-control" id="Total" name="Total" placeholder="Amount" value="<?php echo e(old('Total') ? old('Total') : '0'); ?>" readonly>
                </div>
            </div>

            <input type="hidden" id="checked_rooms_id" name="checked_rooms_id" value="">

            <button type="submit" class="btn btn-primary save-btn">Save changes</button>
        </form>
    </div>
</div>
<div class="div-gap"></div>
<div class="card">
    <div class="card-body">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Room Number</th>
                    <th>Destination</th>
                    <th>Number of Dayes</th>
                    <th>Vehicle Number</th>
                    <th>Amount</th>
                    <th>Tax</th>
                    <th>Date</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $taxi_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxi_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($taxi_bill->rm_number); ?></td>
                    <td><?php echo e($taxi_bill->tx_destination); ?></td>
                    <td><?php echo e($taxi_bill->tx_num_of_days); ?></td>
                    <td><?php echo e($taxi_bill->tx_vehicle_num); ?></td>
                    <td><?php echo e($taxi_bill->tx_amount); ?></td>
                    <td><?php echo e($taxi_bill->tx_tax); ?></td>
                    <td><?php echo e($taxi_bill->tx_issue_date); ?></td>
                    <td><?php echo e($taxi_bill->tx_amount + $taxi_bill->tx_tax); ?></td>
                    <?php if( $taxi_bill->tx_status == env('PAID')): ?>
                    <td>Paid</td>
                    <?php endif; ?>
                    <?php if( $taxi_bill->tx_status == env('UNPAID')): ?>
                    <td>Un Paid</td>
                    <?php endif; ?>
                    <?php if( $taxi_bill->tx_status == env('CANCELED')): ?>
                    <td>Canceled</td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('taxi-bill.cancel',$taxi_bill->taxi_id)); ?>">Cancel</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- <div class="row">
    <table>
        <tr>
            <th>Room Number</th>
            <th>Destination</th>
            <th>Number Of Dayes</th>
            <th>tx_vehicle_num</th>
            <th>tx_amount</th>
            <th>tx_tax</th>
            <th>date</th>
            <th>total</th>
            <th>status</th>
            <th>action</th>
        </tr>
        <?php $__currentLoopData = $taxi_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taxi_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($taxi_bill->rm_number); ?></td>
            <td><?php echo e($taxi_bill->tx_destination); ?></td>
            <td><?php echo e($taxi_bill->tx_num_of_days); ?></td>
            <td><?php echo e($taxi_bill->tx_vehicle_num); ?></td>
            <td><?php echo e($taxi_bill->tx_amount); ?></td>
            <td><?php echo e($taxi_bill->tx_tax); ?></td>
            <td><?php echo e($taxi_bill->tx_issue_date); ?></td>
            <td><?php echo e($taxi_bill->tx_amount + $taxi_bill->tx_tax); ?></td>
            <?php if( $taxi_bill->tx_status == env('PAID')): ?>
            <td>Paid</td>
            <?php endif; ?>
            <?php if( $taxi_bill->tx_status == env('UNPAID')): ?>
            <td>Un Paid</td>
            <?php endif; ?>
            <?php if( $taxi_bill->tx_status == env('CANCELED')): ?>
            <td>Canceled</td>
            <?php endif; ?>
            <td>
                <a href="<?php echo e(route('taxi-bill.cancel',$taxi_bill->taxi_id)); ?>">Cancel</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function getRoomData() {
        let roomId = $('#roomSelect').val();
        let _token = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('room-bills.getByRoom')); ?>",
            data: {
                id: roomId,
                _token: _token
            },
            success: function(data) {
                $('#checked_rooms_id').val(data.checked_rooms_id);
                $('#guest').val(data.gs_name);
                console.log(data);
            }
        });
    }

    function calCost() {
        let tx_num_of_days = $('#tx_num_of_days').val();
        let tx_amount = $('#tx_amount').val();
        let tx_tax = $('#tx_tax').val();

        let tax_amout = ((tx_num_of_days * tx_amount) * tx_tax) / 100;

        let lkr_cost = (tx_num_of_days * tx_amount) + tax_amout;

        $('#Total').val(lkr_cost);


    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Infact_Project\hotel-system\resources\views/bill/taxi_bill.blade.php ENDPATH**/ ?>