

<?php $__env->startSection('css'); ?>

<style type="text/css">
    .save-btn {
        float: right;
    }

    .div-gap {
        margin-bottom: 2em;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('restaurant-bill.add')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Room Id</label>
                    <select class="form-control" id="roomSelect" onclick="getRoomData()">
                        <option value="null">select room</option>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['checked_rooms_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Guest Name</label>
                    <input type="text" class="form-control" name="guest" id="guest" placeholder="Jone Doe" readonly>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Item Code</label>
                    <select class="form-control" name="items_id" id="items_id" onclick="getItemData()">
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->itm_item_code); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="itm_item_price" id="itm_item_price" value="0">
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Quentity</label>
                    <input type="text" class="form-control" id="or_quantity" name="or_quantity" onkeyup="calTot()" placeholder="Quentity" value="<?php echo e(old('or_quantity')); ?>">
                    <?php $__errorArgs = ['or_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputCity">Service charge (%)</label>
                    <input type="text" class="form-control" id="or_service_chrge" name="or_service_chrge" onkeyup="calTot()" value="0" placeholder="Service charge" >
                    <?php $__errorArgs = ['or_service_chrge'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4">
                    <label for="inputState">Total</label>
                    <input type="text" class="form-control" id="or_tot" name="or_tot" readonly value="0" placeholder="Total">
                </div>
            </div>
            <input type="hidden" id="checked_rooms_id" name="checked_rooms_id" value="">
            <button type="submit" class="btn btn-primary save-btn">Save Changes</button>
        </form>
    </div>
</div>

<div class="div-gap"></div>
<div class="card">
    <div class="card-body">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Room Number</th>
                    <th>Item Description</th>
                    <th>Item Code</th>
                    <th>Item Name</th>
                    <th>Order Total</th>
                    <th>Order Quantity</th>
                    <th>Order Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $restaurant_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <img src="<?php echo e(asset('upload/'.$restaurant_bill->itm_img)); ?>" alt="" srcset="" style="width: 40px;">
                    </td>
                    <td><?php echo e($restaurant_bill->rm_number); ?></td>
                    <td><?php echo e($restaurant_bill->itm_description); ?></td>
                    <td><?php echo e($restaurant_bill->itm_item_code); ?></td>
                    <td><?php echo e($restaurant_bill->itm_item_name); ?></td>
                    <td><?php echo e($restaurant_bill->or_tot); ?></td>
                    <td><?php echo e($restaurant_bill->or_quantity); ?></td>
                    <?php if( $restaurant_bill->or_status == env('PAID')): ?>
                    <td>Paid</td>
                    <?php endif; ?>
                    <?php if( $restaurant_bill->or_status == env('UNPAID')): ?>
                    <td>Un Paid</td>
                    <?php endif; ?>
                    <?php if( $restaurant_bill->or_status == env('CANCELED')): ?>
                    <td>Canceled</td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('restaurant-bill.cancel',$restaurant_bill->orders_id)); ?>">Cancel</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<!-- <div class="row">
    <form action="<?php echo e(route('restaurant-bill.add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <select id="roomSelect" onclick="getRoomData()">
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="text" name="guest" id="guest" readonly>
        <br>
        item code
        <select name="items_id" id="items_id" onclick="getItemData()">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->itm_item_code); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="hidden" name="itm_item_price" id="itm_item_price" value="0">
        <br>
        quentity
        <input type="text" placeholder="or_quantity" id="or_quantity" name="or_quantity" onkeyup="calTot()" value="0">
        <br>
        service charge
        <input type="text" placeholder="or_service_chrge" id="or_service_chrge" name="or_service_chrge" onkeyup="calTot()" value="0">
        <br>
        total
        <input type="text" placeholder="or_tot" id="or_tot" name="or_tot" readonly value="0">
        <br>
        <input type="hidden" id="checked_rooms_id" name="checked_rooms_id" value="">
        <button type="submit" class="btn btn-primary">Save changes</button>
    </form>
</div> -->
<!-- <div class="row">
    <table>
        <tr>
            <th>itm_img</th>
            <th>Room Number</th>
            <th>itm_description</th>
            <th>itm_item_code</th>
            <th>itm_item_name</th>
            <th>or_tot</th>
            <th>or_quantity</th>
            <th>or_status</th>
            <th>action</th>
        </tr>
        <?php $__currentLoopData = $restaurant_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restaurant_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <img src="<?php echo e(asset('upload/'.$restaurant_bill->itm_img)); ?>" alt="" srcset="" style="width: 40px;">
            </td>
            <td><?php echo e($restaurant_bill->rm_number); ?></td>
            <td><?php echo e($restaurant_bill->itm_description); ?></td>
            <td><?php echo e($restaurant_bill->itm_item_code); ?></td>
            <td><?php echo e($restaurant_bill->itm_item_name); ?></td>
            <td><?php echo e($restaurant_bill->or_tot); ?></td>
            <td><?php echo e($restaurant_bill->or_quantity); ?></td>
            <?php if( $restaurant_bill->or_status == env('PAID')): ?>
            <td>Paid</td>
            <?php endif; ?>
            <?php if( $restaurant_bill->or_status == env('UNPAID')): ?>
            <td>Un Paid</td>
            <?php endif; ?>
            <?php if( $restaurant_bill->or_status == env('CANCELED')): ?>
            <td>Canceled</td>
            <?php endif; ?>
            <td>
                <a href="<?php echo e(route('restaurant-bill.cancel',$restaurant_bill->orders_id)); ?>">Cancel</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div> -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function getRoomData() {
        let roomId = $('#roomSelect').val();
        let _token = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('room-bills.getByRoom')); ?>",
            data: {
                id: roomId,
                _token: _token
            },
            success: function(data) {
                $('#checked_rooms_id').val(data.checked_rooms_id);
                $('#guest').val(data.gs_name);
                console.log(data);
            }
        });
    }

    function calCost() {
        let d_rate = $('#rb_doller_rate').val();
        let d_amount = $('#rb_amount_doller').val();
        let lkr_cost = $d_rate * $d_amount;
        $('#rb_cost').val($lkr_cost);
    }

    function getItemData() {
        let itemsId = $('#items_id').val();
        let _token = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
            type: 'POST',
            url: "<?php echo e(route('restaurant-bills.getItem-data')); ?>",
            data: {
                id: itemsId,
                _token: _token
            },
            success: function(data) {
                $('#itm_item_price').val(data.itm_item_price);
                console.log(data);
            }
        });
    }

    function calTot() {
        let itm_item_price = parseInt($('#itm_item_price').val());
        let or_quantity = parseInt($('#or_quantity').val());

        let or_service_chrge = parseInt($('#or_service_chrge').val());
        if (or_service_chrge > 100) {
            alert('invalid presantage!');
        }
        let service_charge = ((itm_item_price * or_quantity) * or_service_chrge) / 100

        $('#or_tot').val((itm_item_price * or_quantity) + service_charge);

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Infact_Project\hotel-system\resources\views/bill/restaurant_bill.blade.php ENDPATH**/ ?>