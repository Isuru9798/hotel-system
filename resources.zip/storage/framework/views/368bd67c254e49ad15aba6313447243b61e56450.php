

<?php $__env->startSection('css'); ?>

<style type="text/css">
    .save-btn {
        float: right;
    }

    .div-gap {
        margin-bottom: 2em;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('room-bill.add')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputEmail4">Room Id</label>
                    <select class="form-control" id="roomSelect" onclick="getRoomData()">
                        <option value="null">select room</option>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['checked_rooms_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputPassword4">Guest Name</label>
                    <input type="text" class="form-control" name="guest" id="guest" placeholder="Jone Doe" readonly>

                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputAddress">Date</label>
                    <input type="Date" class="form-control" name="rb_issue_date" placeholder="dd/mm/yyyy">
                    <?php $__errorArgs = ['rb_issue_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Doller Rate</label>
                    <input type="text" class="form-control" name="rb_doller_rate" id="rb_doller_rate" placeholder="$ Rate" value="<?php echo e(old('rb_doller_rate')); ?>">
                    <?php $__errorArgs = ['rb_doller_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputCity">Amount By Doller</label>
                    <input type="text" class="form-control" name="rb_amount_doller" id="rb_amount_doller" onkeyup="calCost()" placeholder="Amount By $" value="<?php echo e(old('rb_amount_doller')); ?>">
                    <?php $__errorArgs = ['rb_amount_doller'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress2">Amount By LKR</label>
                    <input type="text" class="form-control" placeholder="Amount By LKR" name="rb_cost" id="rb_cost" value="<?php echo e(old('rb_cost')); ?>">
                    <?php $__errorArgs = ['rb_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <code><?php echo e($message); ?></code>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <input type="hidden" id="checked_rooms_id" name="checked_rooms_id" value="">
            </div>

            <button type="submit" class="btn btn-primary save-btn">Save changes</button>
        </form>
    </div>
</div>
<div class="div-gap"></div>
<div class="card">
    <div class="card-body">
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Room Number</th>
                    <th>doller rate</th>
                    <th>amount_doller</th>
                    <th>amount_lkr</th>
                    <th>date</th>
                    <th>status</th>
                    <th>action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $room_bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room_bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($room_bill->rm_number); ?></td>
                    <td><?php echo e($room_bill->rb_doller_rate); ?></td>
                    <td><?php echo e($room_bill->rb_amount_doller); ?></td>
                    <td><?php echo e($room_bill->rb_cost); ?></td>
                    <td><?php echo e($room_bill->rb_issue_date); ?></td>
                    <?php if( $room_bill->rb_status == env('PAID')): ?>
                    <td>Paid</td>
                    <?php endif; ?>
                    <?php if( $room_bill->rb_status == env('UNPAID')): ?>
                    <td>Un Paid</td>
                    <?php endif; ?>
                    <?php if( $room_bill->rb_status == env('CANCELED')): ?>
                    <td>Canceled</td>
                    <?php endif; ?>
                    <td>
                        <a href="<?php echo e(route('room-bill.cancel',$room_bill->room_bill_id)); ?>">Cancel</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<!-- <div class="row">
    <form action="<?php echo e(route('room-bill.add')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <select id="roomSelect" onclick="getRoomData()">
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($room->id); ?>"><?php echo e($room->rm_number); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="text" name="guest" id="guest" readonly>
        <input type="date" name="rb_issue_date" placeholder="rb_issue_date">
        <input type="text" placeholder="$ rate" id="rb_doller_rate" name="rb_doller_rate" value="0">
        <input type="text" placeholder="amount by $" id="rb_amount_doller" name="rb_amount_doller" value="0" onkeyup="calCost()">
        <input type="text" placeholder="amount by LKR" name="rb_cost" value="0" id="rb_cost">

        <button type="submit" class="btn btn-primary">Save changes</button>
    </form>
</div> -->
<!--  -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    function getRoomData() {
        let roomId = $('#roomSelect').val();
        let _token = $('meta[name="csrf-token"]').attr('content');
        if (roomId !== 0) {
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('room-bills.getByRoom')); ?>",
                data: {
                    id: roomId,
                    _token: _token
                },
                success: function(data) {
                    $('#checked_rooms_id').val(data.checked_rooms_id);
                    $('#guest').val(data.gs_name);
                    console.log(data);
                }
            });
        } else {
            alert('please select room')
        }
    }

    function calCost() {
        $d_rate = $('#rb_doller_rate').val();
        $d_amount = $('#rb_amount_doller').val();
        $lkr_cost = $d_rate * $d_amount;
        $('#rb_cost').val($lkr_cost);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Infact_Project\hotel-system\resources\views/bill/room_bill.blade.php ENDPATH**/ ?>